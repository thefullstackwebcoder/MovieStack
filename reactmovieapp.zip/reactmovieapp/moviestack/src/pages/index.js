export {Movielist} from "./Movielist"
export {Moviedetails} from "./Moviedetails"
export {Pagenotfound} from "./Pagenotfound"
export {Topratedmovies} from "./Topratedmovies"
export {Search} from "./Search"
export {Popularmovies} from "./Popularmovies"
export {Upcomingmovies} from "./Upcomingmovies"

