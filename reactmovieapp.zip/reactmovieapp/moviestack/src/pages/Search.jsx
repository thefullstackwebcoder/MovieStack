import {Card} from "../components/Card";
import { useSearchParams } from "react-router-dom";
import { useFetch } from "../hooks/useFetch";
import { useEffect } from "react";

export const Search = ({apiPath}) => {
  const [searchParams]=useSearchParams();
  const queryTerm=searchParams.get("q");
  const {data:movies}=useFetch(apiPath,queryTerm);
  useEffect(()=>{
    document.title=`Search result for ${queryTerm}  `;
  });
  return (

    <main className="container">
  <h5 className="text-danger py-2 border-bottom">Search</h5>
  {movies.length==0?`No results found for ${queryTerm}`:`Result for ${queryTerm}`}
  <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3 py-3">
        {movies.map((movie)=>{
          return <Card key={movie.id} movie={movie}/>;        })}
        
       </div>
    </main>
  )
}


