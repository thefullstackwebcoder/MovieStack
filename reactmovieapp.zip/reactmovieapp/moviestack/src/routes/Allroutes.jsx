import React from "react"
import { Routes,Route } from "react-router-dom"
import { Moviedetails, Movielist, Pagenotfound, Search } from "../pages"

const Allroutes = () => {
  return (
   <Routes>
    <Route path="/" element={<Movielist title="Explore amazing movies" apiPath="movie/now_playing"/>}/>
    <Route path="movie/:id" element={<Moviedetails />}/>
    <Route path="movie/top" element={<Movielist title="Top Rated Movies" apiPath="movie/top_rated"/>}/>
    <Route path="movie/upcoming" element={<Movielist title="Upcoming Movies" apiPath="movie/upcoming"/>}/>
    <Route path="movie/popular" element={<Movielist title="Popular Movies" apiPath="movie/popular"/>}/>
    <Route path="search" element={<Search  apiPath="search/movie"/>}/>
    <Route path="*" element={<Pagenotfound title="Page Not Found"/>}/>
    </Routes>
  )
}

export default Allroutes
