import { NavLink } from "react-router-dom"
import {useNavigate} from "react-router-dom"


export const Header = () => {
  const navigator=useNavigate();
  const handleSearch=(e)=>{
    e.preventDefault();
    const queryTerm=e.target.search.value;
    e.target.reset();
    return navigator(`/search?q=${queryTerm}`);

  }
  return (
    <nav className="navbar navbar-expand-md navbar-dark bg-primary top-fixed ">
        <div className="container-fluid">
            <NavLink to="/" className="navbar-brand">MovieStack <i className="bi bi-camera-reels"></i></NavLink>
           <button type="button" className="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">

            <span className="navbar-toggler-icon"></span>
           </button>
       
        <div className="collapse navbar-collapse" id="menu">
          <ul className="navbar-nav me-auto mb-2 mb-md-0">
            <li className="nav-item">
              <NavLink className="nav-link" to="/">Home</NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/movie/popular">Popular</NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/movie/top">TopRated</NavLink>
            </li>
             <li className="nav-item">
              <NavLink className="nav-link" to="/movie/upcoming">Upcoming</NavLink>
            </li>
            </ul>
            <form onSubmit={handleSearch}>
              <input type="search" className="form-control " name="search" placeholder="Search"/>

            </form>
         
        </div>
</div>
  
    </nav>
  )
}


