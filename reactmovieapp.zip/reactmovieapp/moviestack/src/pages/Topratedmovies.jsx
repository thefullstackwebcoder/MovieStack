import React from 'react'

export const Topratedmovies = () => {
  return (
    <div>
      topratedmovies
    </div>
  )
}


