import error from "../assets/error.png";
import { Link } from "react-router-dom";

export const Pagenotfound = () => {
  return (
    <div className="container">
      <img src={error} className="img-fluid"/>
      <p className="text-center mt-5"><Link to="/" className="btn btn-danger">Go to HomePage</Link></p>
    </div>
  )
}


