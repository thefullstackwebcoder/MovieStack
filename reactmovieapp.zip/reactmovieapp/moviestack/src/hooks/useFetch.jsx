
import {useState,useEffect} from "react";

export const useFetch = (apiPath,queryTerm="") => {
     
    const [data,setData]=useState([]);
    const key="10e5027ad789ae2f3b0bbd15693e78bc";
   
    const url=`https://api.themoviedb.org/3/${apiPath}?api_key=${key}&query=${queryTerm}`;
    
 useEffect(()=>{async function fetchMovies(){
    fetch(url).then((res)=>res.json()).then((jsondata)=>setData(jsondata.results));}
    fetchMovies();
},[url]);

return {data};};
