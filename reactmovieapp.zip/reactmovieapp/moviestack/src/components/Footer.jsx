
export const Footer = () => {
  return (
    <div className="container">
      <footer className="py-2 my-5 border-top">
        <p className="text-center text-body-secondary">&copy; 2025 MovieStack,Inc</p> 
      </footer>
    </div>
  )
}


