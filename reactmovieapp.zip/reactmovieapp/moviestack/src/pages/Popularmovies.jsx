import React from 'react'

export const Popularmovies = () => {
  return (
    <div>
      popularmovies
    </div>
  )
}

