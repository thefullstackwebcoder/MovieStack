import { useEffect } from "react";
import {Card} from "../components";
import { useNavigate } from "react-router-dom";
import {useFetch} from "../hooks/useFetch";

export const Movielist = ({title,apiPath}) => {
 
  const {data:movies}=useFetch(apiPath);
  
  
  useEffect(()=>{document.title=title});
  const navigator=useNavigate();
  return(
   <div>
      <main className="container">
        {title=="Explore amazing movies"?(<div className="bg-body-tertiary p-5 border mb-5">
          <h3 className="text-primary">Welcome to Movie Stack</h3>
            <p className="lead">Discover fantastic collections of movies,get personalised 
              suggestions and enjoy watching your favourite cinema </p>
              <button className="btn btn-primary" onClick={()=>{navigator("/movie/upcoming")}}>Explore Now</button>
        </div> ):("")}
       
        <h5 className="text-danger py-2 border-bottom">{title}</h5>
        <div className="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-3 py-3">
        {movies.map((movie)=>{
          return <Card key={movie.id} movie={movie}/>;        })}
        
       </div>
      
      </main>
      </div>
      
   
  )
}


 