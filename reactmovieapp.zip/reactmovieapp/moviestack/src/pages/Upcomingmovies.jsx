import React from 'react'

export const Upcomingmovies = () => {
  return (
    <div>
      upcomingmovies
    </div>
  )
}


